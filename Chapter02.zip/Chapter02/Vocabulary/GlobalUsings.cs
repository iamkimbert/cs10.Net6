﻿global using System; // import the System namespace
global using System.Linq;
global using System.Collections.Generic;