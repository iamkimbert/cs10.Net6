﻿using static System.Console;
namespace Formatting
{
    class Program
    {
        static void Main(string[] args)
             {
            WriteLine("Text");
        }
    }
}